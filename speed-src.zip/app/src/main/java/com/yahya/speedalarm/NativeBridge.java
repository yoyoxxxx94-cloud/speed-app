package com.yahya.speedalarm;

import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;

/** الجسر بين الصفحة وأندرويد. */
public class NativeBridge {
    private final MainActivity act;
    private MediaPlayer preview;
    private android.media.MediaRecorder rec;
    private File recFile;

    NativeBridge(MainActivity a) {
        act = a;
    }

    private SharedPreferences prefs() {
        return act.getSharedPreferences("speed_prefs", android.content.Context.MODE_PRIVATE);
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }

    // ---------- الإعدادات ----------

    private static String cleanTone(String t) {
        if (t.startsWith("sys:")) return t;
        return t.replaceAll("[^A-Za-z0-9_]", "");
    }

    @JavascriptInterface
    public void pickRingtone(final String kind) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.pickRingtone(kind);
            }
        });
    }

    @JavascriptInterface
    public String getCfg() {
        try {
            SharedPreferences p = prefs();
            JSONObject o = new JSONObject();
            o.put("limit", p.getInt("limit", 80));
            o.put("t0", p.getString("t0", "t0_ding"));
            o.put("t1", p.getString("t1", "t1_stall"));
            o.put("t2", p.getString("t2", "t1_radar"));
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void setCfg(String json) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences.Editor e = prefs().edit();
            if (o.has("limit")) e.putInt("limit", o.getInt("limit"));
            if (o.has("t0")) e.putString("t0", cleanTone(o.getString("t0")));
            if (o.has("t1")) e.putString("t1", cleanTone(o.getString("t1")));
            if (o.has("t2")) e.putString("t2", cleanTone(o.getString("t2")));
            e.apply();
        } catch (Exception ignored) {
        }
    }

    // ---------- المراقبة ----------

    @JavascriptInterface
    public void startMon() {
        act.requestStart();
    }

    @JavascriptInterface
    public void stopMon() {
        act.stopMonitor();
    }

    @JavascriptInterface
    public boolean isRunning() {
        return SpeedService.running;
    }

    // ---------- أصوات المستخدم ----------

    @JavascriptInterface
    public String getVoice(String key) {
        try {
            File f = SoundUtil.voiceFile(act, key);
            if (!f.exists()) return "";
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    @JavascriptInterface
    public void exportFile(String name, String b64) {
        act.exportFile(name, Base64.decode(b64, Base64.DEFAULT));
    }

    @JavascriptInterface
    public void importFile() {
        act.importFile();
    }

    @JavascriptInterface
    public boolean storeVoice(String key, String b64) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            File f = SoundUtil.voiceFile(act, key);
            File d = f.getParentFile();
            if (d != null && !d.exists()) d.mkdirs();
            FileOutputStream os = new FileOutputStream(f);
            os.write(data);
            os.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean removeVoice(String key) {
        try {
            return SoundUtil.voiceFile(act, key).delete();
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public String voices() {
        JSONArray a = new JSONArray();
        try {
            File[] fs = new File(act.getFilesDir(), "voices").listFiles();
            if (fs != null) for (File f : fs) a.put(f.getName());
        } catch (Exception ignored) {
        }
        return a.toString();
    }

    @JavascriptInterface
    public void previewVoice(String key) {
        stopPreview();
        preview = SoundUtil.playFile(SoundUtil.voiceFile(act, key));
    }

    @JavascriptInterface
    public void previewTone(String name, float rate) {
        stopPreview();
        if (name.startsWith("sys:")) {
            preview = SoundUtil.playUri(act, name.substring(4));
            return;
        }
        preview = SoundUtil.playRaw(act, name.replaceAll("[^A-Za-z0-9_]", ""), rate <= 0 ? 1f : rate);
    }

    private void stopPreview() {
        SoundUtil.release(preview);
        preview = null;
    }

    // ---------- التسجيل ----------

    private void recQuiet() {
        try {
            if (rec != null) {
                try {
                    rec.stop();
                } catch (Exception ignored) {
                }
                rec.release();
            }
        } catch (Exception ignored) {
        }
        rec = null;
    }

    @JavascriptInterface
    public String recStart() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 23
                    && act.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return "perm";
            }
            recQuiet();
            recFile = new File(act.getCacheDir(), "rec.m4a");
            rec = new android.media.MediaRecorder();
            rec.setAudioSource(android.media.MediaRecorder.AudioSource.MIC);
            rec.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);
            rec.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);
            rec.setAudioChannels(1);
            rec.setAudioSamplingRate(22050);
            rec.setAudioEncodingBitRate(64000);
            rec.setOutputFile(recFile.getAbsolutePath());
            rec.prepare();
            rec.start();
            return "ok";
        } catch (Exception e) {
            recQuiet();
            return "err:" + e;
        }
    }

    @JavascriptInterface
    public String recStop() {
        try {
            recQuiet();
            if (recFile == null || !recFile.exists()) return "";
            java.io.FileInputStream in = new java.io.FileInputStream(recFile);
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            recFile.delete();
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    /** يطلب إذن الميكروفون مسبقًا (قبل أول تسجيل). */
    @JavascriptInterface
    public void askMic() {
        act.askMic();
    }
}
