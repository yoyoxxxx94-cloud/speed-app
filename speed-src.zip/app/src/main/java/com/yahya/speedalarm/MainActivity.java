package com.yahya.speedalarm;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;

/** غلاف WebView لمنبه السرعة. */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String HOME = "https://" + HOST + "/assets/index.html";
    private static final int REQ_LOC = 31;
    private static final int REQ_MIC = 32;
    private static final int REQ_MICWEB = 33;
    private static final int REQ_RING = 34;
    private static final int REQ_EXP = 35;
    private static final int REQ_IMP = 36;
    private byte[] pendingExport;
    private String ringKind = "0";

    private WebView web;
    private android.webkit.PermissionRequest pendingPerm;
    private boolean battAsked = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String sc = u.getScheme();
                if ("blob".equals(sc) || "data".equals(sc) || "about".equals(sc)) return false;
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final android.webkit.PermissionRequest req) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (Build.VERSION.SDK_INT >= 23
                                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            pendingPerm = req;
                            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MICWEB);
                        } else {
                            req.grant(req.getResources());
                        }
                    }
                });
            }
        });

        web.addJavascriptInterface(new NativeBridge(this), "Android");
        if (b == null || web.restoreState(b) == null) web.loadUrl(HOME);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onResume() {
        super.onResume();
        SpeedService.hook = new SpeedService.Hook() {
            @Override
            public void onSpeed(int shown, boolean over, String status) {
                js("window.__spd&&__spd(" + shown + "," + over + "," + org.json.JSONObject.quote(status) + ")");
            }

            @Override
            public void onState(boolean running) {
                js("window.__monState&&__monState(" + running + ")");
            }
        };
        js("window.__monState&&__monState(" + SpeedService.running + ")");
        if (SpeedService.running) {
            js("window.__spd&&__spd(" + SpeedService.lastShown + ",false," + org.json.JSONObject.quote(SpeedService.lastStatus) + ")");
        }
    }

    @Override
    protected void onPause() {
        SpeedService.hook = null;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        SpeedService.hook = null;
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        super.onDestroy();
    }

    private void js(final String code) {
        if (web == null) return;
        web.post(new Runnable() {
            @Override
            public void run() {
                try {
                    web.evaluateJavascript(code, null);
                } catch (Exception ignored) {
                }
            }
        });
    }

    // ---------- بدء الخدمة وإيقافها ----------

    void requestStart() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 23) {
                    ArrayList<String> need = new ArrayList<String>();
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
                        need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
                    }
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        need.add(Manifest.permission.POST_NOTIFICATIONS);
                    }
                    if (!need.isEmpty()) {
                        requestPermissions(need.toArray(new String[0]), REQ_LOC);
                        return;
                    }
                }
                launchService();
            }
        });
    }

    private void launchService() {
        try {
            Intent i = new Intent(this, SpeedService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception e) {
            js("window.__monState&&__monState(false)");
            return;
        }
        askBattery();
    }

    void stopMonitor() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    startService(new Intent(MainActivity.this, SpeedService.class).setAction(SpeedService.ACT_STOP));
                } catch (Exception ignored) {
                }
            }
        });
    }

    void exportFile(String name, byte[] data) {
        pendingExport = data;
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, name);
            startActivityForResult(i, REQ_EXP);
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "تعذّر التصدير", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    void importFile() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_IMP);
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "تعذّر الاستيراد", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    void pickRingtone(String kind) {
        ringKind = kind;
        try {
            Intent i = new Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER);
            i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALL);
            i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
            i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
            startActivityForResult(i, REQ_RING);
        } catch (Exception e) {
            js("window.toast&&toast('تعذّر فتح قائمة النغمات')");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_EXP) {
            if (res == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(data.getData());
                    os.write(pendingExport);
                    os.close();
                    android.widget.Toast.makeText(this, "تم حفظ الملف", android.widget.Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    android.widget.Toast.makeText(this, "تعذّر حفظ الملف", android.widget.Toast.LENGTH_SHORT).show();
                }
            }
            pendingExport = null;
            return;
        }
        if (req == REQ_IMP) {
            if (res == RESULT_OK && data != null && data.getData() != null) {
                try {
                    java.io.InputStream in = getContentResolver().openInputStream(data.getData());
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) bo.write(b, 0, n);
                    in.close();
                    String s64 = android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP);
                    js("window.__imported&&__imported(" + org.json.JSONObject.quote(s64) + ")");
                } catch (Exception e) {
                    android.widget.Toast.makeText(this, "تعذّر قراءة الملف", android.widget.Toast.LENGTH_SHORT).show();
                }
            }
            return;
        }
        if (req == REQ_RING && res == RESULT_OK && data != null) {
            Uri u = data.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (u != null) {
                String title = "";
                try {
                    android.media.Ringtone r = android.media.RingtoneManager.getRingtone(this, u);
                    if (r != null) title = r.getTitle(this);
                } catch (Exception ignored) {
                }
                js("window.__ringPicked&&__ringPicked(" + org.json.JSONObject.quote(ringKind) + ","
                        + org.json.JSONObject.quote(u.toString()) + "," + org.json.JSONObject.quote(title) + ")");
            }
        }
    }

    void askMic() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 23
                        && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                }
            }
        });
    }

    /** يطلب مرة واحدة السماح بعدم توفير البطارية حتى لا يوقف الجهاز المراقبة. */
    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (battAsked || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            if (getSharedPreferences("speed_prefs", MODE_PRIVATE).getBoolean("asked_batt", false)) return;
            battAsked = true;
            getSharedPreferences("speed_prefs", MODE_PRIVATE).edit().putBoolean("asked_batt", true).apply();
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LOC) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                launchService();
            } else {
                js("window.__monState&&__monState(false)");
                js("window.__spd&&__spd(5,false,'الموقع غير مسموح. اسمح به من إعدادات الجوال')");
            }
        } else if (code == REQ_MICWEB) {
            if (pendingPerm != null) {
                if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pendingPerm.grant(pendingPerm.getResources());
                else pendingPerm.deny();
                pendingPerm = null;
            }
        }
    }
}
