package com.yahya.speedalarm;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;

import java.io.File;

/** تشغيل نغمات التطبيق (raw) وأصوات المستخدم المسجّلة. */
final class SoundUtil {
    private SoundUtil() {
    }

    static AudioAttributes attrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    static void release(MediaPlayer mp) {
        if (mp == null) return;
        try {
            mp.stop();
        } catch (Exception ignored) {
        }
        try {
            mp.release();
        } catch (Exception ignored) {
        }
    }

    /** يشغّل ملف raw باسمه (مثل t0_ding). rate: سرعة التشغيل (1 عادي). */
    static MediaPlayer playRaw(Context c, String name, float rate) {
        try {
            int id = c.getResources().getIdentifier(name, "raw", c.getPackageName());
            if (id == 0) return null;
            AssetFileDescriptor afd = c.getResources().openRawResourceFd(id);
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(attrs());
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.prepare();
            if (rate != 1f && Build.VERSION.SDK_INT >= 23) {
                try {
                    mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(rate));
                } catch (Exception ignored) {
                }
            }
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    release(m);
                }
            });
            mp.start();
            return mp;
        } catch (Exception e) {
            return null;
        }
    }

    /** يشغّل نغمة من الجهاز (رنة/منبّه/إشعار) من عنوانها. */
    static MediaPlayer playUri(Context c, String uri) {
        try {
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(attrs());
            mp.setDataSource(c, android.net.Uri.parse(uri));
            mp.prepare();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    release(m);
                }
            });
            mp.start();
            return mp;
        } catch (Exception e) {
            return null;
        }
    }

    /** يشغّل ملف صوتي من مسار (تسجيل المستخدم). */
    static MediaPlayer playFile(File f) {
        try {
            if (f == null || !f.exists()) return null;
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(attrs());
            mp.setDataSource(f.getAbsolutePath());
            mp.prepare();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    release(m);
                }
            });
            mp.start();
            return mp;
        } catch (Exception e) {
            return null;
        }
    }

    static File voiceFile(Context c, String key) {
        File d = new File(c.getFilesDir(), "voices");
        return new File(d, key.replaceAll("[^A-Za-z0-9_]", "_"));
    }
}
