package com.yahya.speedalarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/** خدمة المراقبة: تقرأ GPS وتشغّل التنبيهات والشاشة مقفلة. */
public class SpeedService extends Service {
    static final String ACT_STOP = "com.yahya.speedalarm.STOP";
    static final int OFFSET = 5;
    static final long[] INTERVAL = {5000, 2500, 1500};
    static final long VOICE_EVERY = 9000;
    private static final String CH = "speed_ch";

    interface Hook {
        void onSpeed(int shown, boolean over, String status);

        void onState(boolean running);
    }

    static volatile boolean running = false;
    static volatile int lastShown = OFFSET;
    static volatile String lastStatus = "";
    static Hook hook;

    private LocationManager lm;
    private LocationListener ll;
    private Handler h;
    private PowerManager.WakeLock wl;
    private double rawS = 0;
    private Location lastLoc;
    private boolean overFlag = false;
    private int lastLvl = -1;
    private long lastVoice = 0, lastTone = 0;
    private MediaPlayer tonePl, voicePl;
    private AudioManager am;
    private AudioFocusRequest focusReq;
    private boolean hasFocus = false;
    private final AudioManager.OnAudioFocusChangeListener focusListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int change) {
        }
    };
    private TextToSpeech tts;
    private boolean ttsOk = false;
    private SharedPreferences prefs;
    private int curLimit = 80;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            doTick();
            if (running) h.postDelayed(this, 250);
        }
    };

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        h = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences("speed_prefs", MODE_PRIVATE);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_STOP.equals(intent.getAction())) {
            stopMon();
            return START_NOT_STICKY;
        }
        if (running) return START_STICKY;
        startMon();
        return START_STICKY;
    }

    private Notification buildNote() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "منبه السرعة", NotificationManager.IMPORTANCE_LOW);
            c.setSound(null, null);
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, fl);
        Intent stop = new Intent(this, SpeedService.class).setAction(ACT_STOP);
        PendingIntent ps = PendingIntent.getService(this, 2, stop, fl);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_speed)
                .setContentTitle("منبه السرعة يعمل")
                .setContentText("الحد المسموح: " + prefs.getInt("limit", 80) + " كم/س")
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(R.drawable.ic_stat_speed, "إيقاف", ps);
        return b.build();
    }

    private void startMon() {
        try {
            Notification n = buildNote();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(7, n);
            }
        } catch (Exception e) {
            stopSelf();
            return;
        }
        running = true;
        rawS = 0;
        lastLoc = null;
        overFlag = false;
        lastLvl = -1;
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        try {
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "speedalarm:mon");
            wl.acquire();
        } catch (Exception ignored) {
        }
        initTts();
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        ll = new LocationListener() {
            @Override
            public void onLocationChanged(Location loc) {
                onLoc(loc);
            }

            @Override
            public void onStatusChanged(String p, int s, Bundle b) {
            }

            @Override
            public void onProviderEnabled(String p) {
            }

            @Override
            public void onProviderDisabled(String p) {
                lastStatus = "شغّل الموقع (GPS) من إعدادات جوالك";
            }
        };
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, ll, Looper.getMainLooper());
            lastStatus = "جارٍ طلب الموقع...";
        } catch (SecurityException e) {
            lastStatus = "الموقع غير مسموح";
        } catch (Exception e) {
            lastStatus = "شغّل الموقع (GPS) من إعدادات جوالك";
        }
        playRawSimple("tone_on");
        if (hook != null) hook.onState(true);
        h.removeCallbacks(tick);
        h.post(tick);
    }

    private void stopMon() {
        boolean was = running;
        running = false;
        h.removeCallbacks(tick);
        try {
            if (lm != null && ll != null) lm.removeUpdates(ll);
        } catch (Exception ignored) {
        }
        SoundUtil.release(tonePl);
        SoundUtil.release(voicePl);
        tonePl = null;
        voicePl = null;
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        abandonFocus();
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) {
        }
        lastShown = OFFSET;
        lastStatus = "المراقبة متوقفة";
        if (was) playRawSimple("tone_off");
        if (hook != null) {
            hook.onState(false);
            hook.onSpeed(OFFSET, false, lastStatus);
        }
        stopForeground(true);
        // نترك الخدمة حيّة قليلًا ليكتمل صوت الإيقاف
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopSelf();
            }
        }, 1500);
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    private void initTts() {
        if (tts != null) return;
        try {
            tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status == TextToSpeech.SUCCESS) {
                        int r = tts.setLanguage(new Locale("ar"));
                        ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                    }
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void onLoc(Location loc) {
        double s;
        if (loc.hasSpeed()) {
            s = loc.getSpeed();
        } else if (lastLoc != null) {
            double dt = (loc.getTime() - lastLoc.getTime()) / 1000.0;
            s = dt > 0 ? loc.distanceTo(lastLoc) / dt : 0;
        } else {
            s = 0;
        }
        lastLoc = loc;
        double raw = Math.max(0, s * 3.6);
        rawS = raw < 3 ? 0 : rawS * 0.35 + raw * 0.65;
        lastStatus = "GPS متصل · الدقة " + Math.round(loc.getAccuracy()) + " م";
    }

    private void doTick() {
        curLimit = prefs.getInt("limit", 80);
        int shown = (int) Math.round(rawS) + OFFSET;
        boolean over = shown >= curLimit;
        int lvl = over ? (shown >= curLimit + 10 ? 2 : shown >= curLimit + 5 ? 1 : 0) : -1;
        lastShown = shown;
        if (hook != null) hook.onSpeed(shown, over, lastStatus);
        if (lvl >= 0) {
            speedAlert(lvl);
        } else {
            if (overFlag) abandonFocus();
            overFlag = false;
            lastLvl = -1;
        }
    }

    private void speedAlert(int level) {
        long n = System.currentTimeMillis();
        if (!overFlag) {
            overFlag = true;
            lastLvl = level;
            lastTone = n;
            lastVoice = n;
            getFocus();
            playTone(level);
            vibrate(level == 0 ? 250 : 400);
            if (level >= 1) {
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (running && overFlag) playVoice();
                    }
                }, 1100);
            }
            return;
        }
        boolean escalated = level > lastLvl;
        if (escalated || n - lastTone >= INTERVAL[level]) {
            lastLvl = level;
            lastTone = n;
            getFocus();
            playTone(level);
            if (level >= 1) vibrate(200);
        }
        if (level >= 1 && (escalated ? n - lastVoice > 2500 : n - lastVoice >= (level == 2 ? VOICE_EVERY - 3000 : VOICE_EVERY))) {
            lastVoice = n;
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (running && overFlag) playVoice();
                }
            }, 1100);
        }
    }

    private void playTone(int level) {
        String name = prefs.getString("t" + level, level == 0 ? "t0_ding" : level == 1 ? "t1_stall" : "t1_radar");
        SoundUtil.release(tonePl);
        if (name.startsWith("sys:")) {
            final MediaPlayer mp = SoundUtil.playUri(this, name.substring(4));
            tonePl = mp;
            if (mp != null) {
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (tonePl == mp) {
                            SoundUtil.release(mp);
                            tonePl = null;
                        }
                    }
                }, 3500);
            }
            return;
        }
        tonePl = SoundUtil.playRaw(this, name, 1f);
    }

    private void playVoice() {
        int lim = prefs.getInt("limit", 80);
        java.io.File f = SoundUtil.voiceFile(this, "v" + lim);
        SoundUtil.release(voicePl);
        SoundUtil.release(tonePl);
        tonePl = null;
        voicePl = SoundUtil.playFile(f);
        if (voicePl == null && ttsOk && tts != null) {
            try {
                tts.speak("السرعة " + lim, TextToSpeech.QUEUE_FLUSH, null, "spd");
            } catch (Exception ignored) {
            }
        }
    }

    private void playRawSimple(String name) {
        SoundUtil.release(tonePl);
        tonePl = SoundUtil.playRaw(this, name, 1f);
    }

    private void vibrate(int ms) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(ms);
        } catch (Exception ignored) {
        }
    }

    private void getFocus() {
        if (hasFocus) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(SoundUtil.attrs()).setOnAudioFocusChangeListener(focusListener).build();
                hasFocus = am.requestAudioFocus(focusReq) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            } else {
                hasFocus = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
        } catch (Exception ignored) {
        }
    }

    private void abandonFocus() {
        if (!hasFocus) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && focusReq != null) am.abandonAudioFocusRequest(focusReq);
            else am.abandonAudioFocus(focusListener);
        } catch (Exception ignored) {
        }
        hasFocus = false;
    }
}
